"""
Alexis Phillips
3/9/25
Module 08 Final Project

I created the Audio Atlas music application to allow users to listen, create, and 
share in their love of music. 

"""
import tkinter as tk
from tkinter import messagebox, filedialog
from tkinter import PhotoImage
from tkinter import simpledialog  # Import simpledialog

"""create the class."""
class AudioAtlasApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Audio Atlas")
        self.root.geometry("800x700")
        
        # Set up the album cover and user profile picture associated to the path file 
        self.profile_image = PhotoImage(file=r"C:\Users\alexi\Downloads\SDEV 140 ASSIGNMENTS\Final Project\profile picture.png")
        self.album_cover_image = PhotoImage(file=r"C:\Users\alexi\Downloads\SDEV 140 ASSIGNMENTS\Final Project\Heartbreak cover.png")
        
        """This specific song title will be a simulation of how the other songs
        will display the album cover when the user chooses to play the song."""
        self.album_cover = {
            "Heartbreak on a Full Moon - Chris Brown": self.album_cover_image
        }

        # Application Homepage
        self.homePage()

    def homePage(self):
        """Creates the main window with music controls and a library."""
        self.title_label = tk.Label(self.root, text="Audio Atlas", font=("Lucida Calligraphy", 24))
        self.title_label.pack(pady=20)

        self.create_menu()

        # Music Controls Frame
        self.music_features_frame = tk.Frame(self.root)
        self.music_features_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=10)

        self.create_music_controls()

        # Music Library Frame
        self.library_frame = tk.Frame(self.root)
        self.library_frame.pack(fill=tk.BOTH, pady=10)

        self.create_music_library()

        # Profile Button
        self.profile_button = tk.Button(self.root, text="Profile", command=self.open_profile_window)
        self.profile_button.pack(side=tk.TOP, anchor=tk.E, padx=10, pady=10)
   
    # create a menu bar 
    def create_menu(self):
        """Creates a menu bar."""
        menu_bar = tk.Menu(self.root)
        self.root.config(menu=menu_bar)
        file_menu = tk.Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Exit", command=self.root.quit)
    
    #create the music controls
    def create_music_controls(self):
        """Creates play, pause, skip, shuffle buttons."""
        play_button = tk.Button(self.music_features_frame, text="Play", command=self.play_song)
        play_button.pack(side=tk.LEFT, padx=10)

        pause_button = tk.Button(self.music_features_frame, text="Pause", command=self.pause_song)
        pause_button.pack(side=tk.LEFT, padx=10)

        skip_button = tk.Button(self.music_features_frame, text="Skip", command=self.skip_song)
        skip_button.pack(side=tk.LEFT, padx=10)

        shuffle_button = tk.Button(self.music_features_frame, text="Shuffle", command=self.shuffle_playlist)
        shuffle_button.pack(side=tk.LEFT, padx=10)

    #create a music library 
    def create_music_library(self):
        """Creates the music library with a list of songs."""
        self.library_label = tk.Label(self.library_frame, text="Music Library", font=("Helvetica", 18))
        self.library_label.pack(pady=10)

        self.songs_list = [
            "Heartbreak on a Full Moon - Chris Brown",
            "Too Sweet - Hosier",
            "Oh My God - Adele",
            "Why Don't You - Cleo Sol",
        ]
        
        self.songs_listbox = tk.Listbox(self.library_frame)
        self.songs_listbox.pack(fill=tk.BOTH, expand=True)
        
        for song in self.songs_list:
            self.songs_listbox.insert(tk.END, song)

        play_button = tk.Button(self.library_frame, text="Play Song", command=self.play_song)
        play_button.pack(pady=5)   

        """The search bar will allow the user to look up their song of choice."""
        self.search_bar = tk.Entry(self.library_frame, font=("Helvetica", 12))
        self.search_bar.pack(pady=10, fill=tk.X)

        search_button = tk.Button(self.library_frame, text="Search", command=self.search_music)
        search_button.pack()
    #disply profile window 
    def open_profile_window(self):
        """The profile window is opened when the user clicks the profile button"""
        profile_window = tk.Toplevel(self.root)
        profile_window.title("User Profile")
        profile_window.geometry("700x700")
        
        profile_pic_label = tk.Label(profile_window, image=self.profile_image)
        profile_pic_label.pack(pady=10)

        #display users profile 
        self.profileLabel = tk.Label(profile_window, text="Alexis' Pofile", font=("Helvetica", 16))
        self.profileLabel.pack(pady=10)

        self.create_playlist_section(profile_window)

    def create_playlist_section(self, profile_window):
        """Create a playlist management section."""
        self.playlist_label = tk.Label(profile_window, text="Playlists", font=("Helvetica", 14))
        self.playlist_label.pack(pady=10)

        self.playlist_button = tk.Button(profile_window, text="Create Playlist", command=self.create_playlist)
        self.playlist_button.pack(pady=5)

    def create_playlist(self):
        """Simulate creating a playlist."""
        playlist_name = self.playlist_name()
        if playlist_name:
          messagebox.showinfo("Success", "Playlist '" + playlist_name + "' created successfully!")


    def playlist_name(self):
        """Prompt user to enter a name for a new playlist."""
        name = simpledialog.askstring("Playlist Name", "Enter the playlist name:")
        if name and len(name) > 0:
            return name
        else:
            messagebox.showerror("Error", "Playlist name cannot be empty!")
            return None

    def search_music(self):
        """Search for music."""
        search_term = self.search_bar.get()
        if not self.validate_input(search_term):
            return
        """This will show the information message"""
        messagebox.showinfo("Search Results", f"Searching for: {search_term}")

    def search_input(self, input_text):
        """This method will make sure that the user does not enter empty string
        into the search bar."""
        if not input_text:
            messagebox.showerror("Input Error", "Search term cannot be empty")
            return False
        return True

# MUSIC CONTROL CALLBACKS
    
    def play_song(self):
       
        """Simulate playing a song and when the user presses the play song button
        it will display the album cover."""
        
        selected_song = self.songs_listbox.get(tk.ACTIVE)
        if selected_song:
            album_cover = self.album_cover.get(selected_song, None)
            if album_cover:
                self.display_album_cover(album_cover)
        messagebox.showinfo("Music Control", "Playing: " + selected_song)


    def display_album_cover(self, album_cover):
        
        """ Added the display album method to simulate the picture of an album 
        cover displaying when the user chooses to play the song."""

        self.album_cover_label = tk.Label(self.root, image=album_cover)
        self.album_cover_label.pack(pady=10)

    """These methods were created to simulate pausing, skipping a song, and shuffling
    a playlist """
    def pause_song(self):
        
        messagebox.showinfo("Music Control", "Song paused.")

    def skip_song(self):
        
        messagebox.showinfo("Music Control", "Song skipped.")

    def shuffle_playlist(self):
        
        messagebox.showinfo("Music Control", "Playlist shuffled.")

# RUN THE APPLICATION
if __name__ == "__main__":
    root = tk.Tk()
    app = AudioAtlasApp(root)
    root.mainloop()